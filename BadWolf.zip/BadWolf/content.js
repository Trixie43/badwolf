function replaceWordsWithBadWolfRandomly() {
    // Get all the text nodes in the document
    const textNodes = [];
    function getTextNodes(element) {
        if (element.nodeType === Node.TEXT_NODE && element.textContent.trim() !== '') {
            textNodes.push(element);
        }
        element.childNodes.forEach(getTextNodes);
    }
    getTextNodes(document.body);  // Gather all text nodes from the body

    // Get all the images in the document
    const images = Array.from(document.querySelectorAll('img'));

    // Randomly replace words and images
    function replaceRandomWord() {
        if (textNodes.length > 0) {
            const randomTextNode = textNodes[Math.floor(Math.random() * textNodes.length)]; // Pick a random text node
            let words = randomTextNode.textContent.split(' ');  // Split text into words
            const randomWordIndex = Math.floor(Math.random() * words.length);  // Pick a random word to replace

            words[randomWordIndex] = 'Bad Wolf';  // Replace the random word
            randomTextNode.textContent = words.join(' ');  // Join the words back together
        }
    }

    function hideRandomImage() {
        if (images.length > 0) {
            const randomImage = images[Math.floor(Math.random() * images.length)];  // Pick a random image
            randomImage.style.display = 'none';  // Hide the image
        }
    }

    setInterval(replaceRandomWord, 500);  // Replace a random word every 1000ms
    setInterval(hideRandomImage, 500);  // Hide a random image every 1000ms
}

replaceWordsWithBadWolfRandomly();  // Start the process

let links = document.querySelectorAll('a');
links.forEach((link) => {
    link.href = 'https://tardis.fandom.com/wiki/Bad_Wolf_(entity)';  // Change all links to Bad Wolf page
    link.target = '_blank';  // Open links in new tab
});
